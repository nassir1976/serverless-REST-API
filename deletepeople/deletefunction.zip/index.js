
'use strict'


const peopleModel = require('./people.schema.js');
const dynamoose = require('dynamoose')
const { v4: uuid } = require('uuid')

exports.handler = async (event) => {

  const id = event.pathParameters.clientID;

  try {
    await clients.delete({ id });
    let reply = JSON.stringify({ "message": `Successfully deleted record ${id}` })
    return {
      statusCode: 200,
      body: reply
    }
  } catch (err) {
    return {
      statusCode: 500,
      body: err.message
    }
  }

}




